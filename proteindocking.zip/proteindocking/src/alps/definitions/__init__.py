__all__ = ['agingscheme', 'crossover', 'selection', 'stopcondition']
